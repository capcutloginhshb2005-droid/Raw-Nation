package com.rawnation.dukanhisab
import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.*
import androidx.core.content.ContextCompat
class MainActivity: AppCompatActivity(){
 lateinit var web:WebView
 @SuppressLint("SetJavaScriptEnabled") override fun onCreate(b:Bundle?){super.onCreate(b);web=WebView(this);web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.webViewClient=WebViewClient();web.addJavascriptInterface(BioBridge(),"AndroidBio");web.loadUrl("file:///android_asset/index.html");setContentView(web)}
 inner class BioBridge{@JavascriptInterface fun authenticate(){val m=BiometricManager.from(this@MainActivity);if(m.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)!=BiometricManager.BIOMETRIC_SUCCESS){web.evaluateJavascript("alert('Biometric unavailable. PIN 1204 ব্যবহার করুন।')",null);return};val p=BiometricPrompt(this@MainActivity,ContextCompat.getMainExecutor(this@MainActivity),object:BiometricPrompt.AuthenticationCallback(){override fun onAuthenticationSucceeded(r:BiometricPrompt.AuthenticationResult){web.evaluateJavascript("unlock()",null)}});p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("RAW NATION").setSubtitle("Face / Fingerprint Verify").setNegativeButtonText("Use PIN").build())}}
}
