const KEY="rawNationHisabV1";
let db=JSON.parse(localStorage.getItem(KEY)||'{"products":[],"sales":[],"purchases":[],"customerDue":[],"supplierDue":[],"expenses":[]}');
let page="dashboard";
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
const money=n=>"৳"+Number(n||0).toLocaleString("en-BD",{maximumFractionDigits:2});
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
const today=()=>new Date().toISOString().slice(0,10);
const stock=p=>Number(p.stock||0);
const salesTotal=()=>db.sales.reduce((a,x)=>a+Number(x.total),0);
const profit=()=>db.sales.reduce((a,x)=>a+(Number(x.price)-Number(x.cost))*Number(x.qty),0)-db.expenses.reduce((a,x)=>a+Number(x.amount),0);
const dueTotal=a=>a.reduce((s,x)=>s+Number(x.due||0),0);

function nav(){
 const items=[["dashboard","🏠 Dashboard"],["products","📦 Stock"],["sale","🛒 Sale"],["purchase","📥 Purchase"],["customerDue","👤 Customer Due"],["supplierDue","🏢 Supplier Due"],["expenses","💸 Expenses"],["backup","💾 Backup"]];
 document.querySelector("#nav").innerHTML=items.map(x=>`<button class="${page==x[0]?'active':''}" onclick="go('${x[0]}')">${x[1]}</button>`).join("");
}
function go(p){page=p;nav();render()}
function render(){
 const a={dashboard:dashboard,products, sale,purchase,customerDue:()=>duePage("customerDue"),supplierDue:()=>duePage("supplierDue"),expenses,backup}[page];
 document.querySelector("#app").innerHTML=a();
}
function dashboard(){
 return `<h2>Raw Nation — Dashboard</h2><div class="grid">
 <div class="card"><div class="muted">মোট পণ্য</div><div class="num">${db.products.length}</div></div>
 <div class="card"><div class="muted">Stock-এর ক্রয়মূল্য</div><div class="num">${money(db.products.reduce((s,p)=>s+stock(p)*Number(p.cost),0))}</div></div>
 <div class="card"><div class="muted">মোট বিক্রি</div><div class="num">${money(salesTotal())}</div></div>
 <div class="card"><div class="muted">আনুমানিক লাভ</div><div class="num ${profit()>=0?'pos':'neg'}">${money(profit())}</div></div>
 <div class="card"><div class="muted">Customer থেকে পাবেন</div><div class="num">${money(dueTotal(db.customerDue))}</div></div>
 <div class="card"><div class="muted">Supplier-কে দেবেন</div><div class="num">${money(dueTotal(db.supplierDue))}</div></div>
 </div><div class="section"><h2>⚠️ Low Stock</h2>${lowStock()}</div>
 <div class="section"><h2>শেষ বিক্রি</h2>${salesTable(db.sales.slice().reverse().slice(0,10))}</div>`;
}
function lowStock(){
 const a=db.products.filter(p=>stock(p)<=Number(p.min||5));
 if(!a.length)return '<div class="card">কোনো Low Stock নেই 🎉</div>';
 return `<table><tr><th>পণ্য</th><th>Stock</th><th>Limit</th></tr>${a.map(p=>`<tr><td>${esc(p.name)}</td><td class="low">${stock(p)}</td><td>${p.min||5}</td></tr>`).join("")}</table>`;
}
function products(){
 return `<h2>📦 Stock / পণ্য</h2><div class="card"><div class="form">
 <input id="pn" placeholder="পণ্যের নাম"><input id="pc" type="number" placeholder="ক্রয়মূল্য/পিস"><input id="ps" type="number" placeholder="বিক্রয়মূল্য/পিস"><input id="pq" type="number" placeholder="শুরু Stock"><input id="pm" type="number" placeholder="Low Stock limit" value="5"><button class="primary" onclick="addProduct()">পণ্য যোগ করুন</button>
 </div></div><table><tr><th>পণ্য</th><th>Stock</th><th>ক্রয়</th><th>বিক্রি</th><th>Stock মূল্য</th><th></th></tr>
 ${db.products.map((p,i)=>`<tr><td>${esc(p.name)}</td><td class="${stock(p)<=Number(p.min||5)?'low':''}">${stock(p)}</td><td>${money(p.cost)}</td><td>${money(p.sell)}</td><td>${money(stock(p)*p.cost)}</td><td><button class="danger" onclick="delProduct(${i})">মুছুন</button></td></tr>`).join("")}</table>`;
}
function sale(){
 return `<h2>🛒 বিক্রি</h2><div class="card"><div class="form">
 <select id="sp">${db.products.map((p,i)=>`<option value="${i}">${esc(p.name)} — Stock ${stock(p)}</option>`).join("")}</select>
 <input id="sq" type="number" min="1" value="1" placeholder="কত পিস"><input id="sprice" type="number" placeholder="বিক্রয়মূল্য/পিস">
 <select id="stype"><option value="cash">Cash</option><option value="due">বাকি</option></select><input id="scustomer" placeholder="Customer name (বাকি হলে)">
 <button class="primary" onclick="addSale()">বিক্রি সংরক্ষণ</button></div></div>${salesTable(db.sales.slice().reverse())}`;
}
function salesTable(a){if(!a.length)return '<div class="card">এখনও বিক্রির হিসাব নেই।</div>';return `<table><tr><th>তারিখ</th><th>পণ্য</th><th>Qty</th><th>মোট</th><th>ধরণ</th></tr>${a.map(x=>`<tr><td>${x.date}</td><td>${esc(x.product)}</td><td>${x.qty}</td><td>${money(x.total)}</td><td>${x.type==="due"?"বাকি":"Cash"}</td></tr>`).join("")}</table>`}
function purchase(){
 return `<h2>📥 Purchase</h2><div class="card"><div class="form">
 <select id="pp">${db.products.map((p,i)=>`<option value="${i}">${esc(p.name)}</option>`).join("")}</select><input id="pqty" type="number" min="1" value="1" placeholder="কত পিস"><input id="pcost" type="number" placeholder="ক্রয়মূল্য/পিস">
 <select id="ptype"><option value="cash">Cash</option><option value="due">Supplier বাকি</option></select><input id="psupplier" placeholder="Supplier name">
 <button class="primary" onclick="addPurchase()">Purchase সংরক্ষণ</button></div></div>
 <table><tr><th>তারিখ</th><th>পণ্য</th><th>Qty</th><th>মোট</th><th>ধরণ</th></tr>${db.purchases.slice().reverse().map(x=>`<tr><td>${x.date}</td><td>${esc(x.product)}</td><td>${x.qty}</td><td>${money(x.total)}</td><td>${x.type==="due"?"বাকি":"Cash"}</td></tr>`).join("")}</table>`;
}
function duePage(kind){
 const arr=kind==="customerDue"?db.customerDue:db.supplierDue, title=kind==="customerDue"?"👤 Customer Due":"🏢 Supplier Due", label=kind==="customerDue"?"Customer":"Supplier";
 return `<h2>${title}</h2><div class="card"><div class="form"><input id="dn" placeholder="${label} name"><input id="da" type="number" placeholder="বাকি টাকা"><input id="dnote" placeholder="নোট"><button class="primary" onclick="addDue('${kind}')">বাকি যোগ করুন</button></div></div>
 <table><tr><th>নাম</th><th>বাকি</th><th>নোট</th><th></th></tr>${arr.map((x,i)=>`<tr><td>${esc(x.name)}</td><td>${money(x.due)}</td><td>${esc(x.note)}</td><td><button class="danger" onclick="removeDue('${kind}',${i})">মুছুন</button></td></tr>`).join("")}</table>`;
}
function expenses(){
 return `<h2>💸 দোকানের খরচ</h2><div class="card"><div class="form"><input id="en" placeholder="খরচের নাম"><input id="ea" type="number" placeholder="টাকা"><button class="primary" onclick="addExpense()">খরচ যোগ করুন</button></div></div>
 <table><tr><th>তারিখ</th><th>খরচ</th><th>টাকা</th></tr>${db.expenses.slice().reverse().map(x=>`<tr><td>${x.date}</td><td>${esc(x.name)}</td><td>${money(x.amount)}</td></tr>`).join("")}</table>`;
}
function backup(){
 return `<h2>💾 Backup / Restore</h2><div class="card"><button onclick="logout()">🚪 Logout</button></div><div class="card"><p>এই browser-এ হিসাব সেভ থাকে। ফোন বদলানোর আগে Backup Download করুন।</p><div class="toolbar"><button onclick="exportData()">⬇️ Backup Download</button><button onclick="document.querySelector('#imp').click()">⬆️ Restore</button><input id="imp" type="file" accept=".json" hidden onchange="importData(event)"></div></div>`;
}
function addProduct(){
 const name=document.querySelector("#pn").value.trim(), cost=+document.querySelector("#pc").value, sell=+document.querySelector("#ps").value, qty=+document.querySelector("#pq").value||0, min=+document.querySelector("#pm").value||5;
 if(!name)return alert("পণ্যের নাম দিন");
 db.products.push({name,cost,sell,stock:qty,min});save();render();
}
function delProduct(i){if(confirm("এই পণ্য মুছবেন?")){db.products.splice(i,1);save();render()}}
function addSale(){
 if(!db.products.length)return alert("আগে পণ্য যোগ করুন");
 const i=+document.querySelector("#sp").value,p=db.products[i],qty=+document.querySelector("#sq").value,price=+document.querySelector("#sprice").value||+p.sell,type=document.querySelector("#stype").value,customer=document.querySelector("#scustomer").value.trim();
 if(qty<1||qty>stock(p))return alert("Stock যথেষ্ট নেই");
 if(type==="due"&&!customer)return alert("বাকি হলে Customer name দিন");
 p.stock-=qty;db.sales.push({date:today(),product:p.name,qty,price,cost:p.cost,total:qty*price,type,customer});if(type==="due")addDueRecord("customerDue",customer,qty*price,"বিক্রির বাকি");save();render();
}
function addPurchase(){
 if(!db.products.length)return alert("আগে পণ্য যোগ করুন");
 const i=+document.querySelector("#pp").value,p=db.products[i],qty=+document.querySelector("#pqty").value,cost=+document.querySelector("#pcost").value||+p.cost,type=document.querySelector("#ptype").value,supplier=document.querySelector("#psupplier").value.trim();
 if(qty<1)return alert("Qty দিন");if(type==="due"&&!supplier)return alert("Supplier name দিন");
 p.stock+=qty;p.cost=cost;db.purchases.push({date:today(),product:p.name,qty,cost,total:qty*cost,type,supplier});if(type==="due")addDueRecord("supplierDue",supplier,qty*cost,"Purchase বাকি");save();render();
}
function addDueRecord(kind,name,amount,note){let arr=db[kind];let old=arr.find(x=>x.name.toLowerCase()===name.toLowerCase());if(old)old.due+=amount;else arr.push({name,due:amount,note})}
function addDue(kind){const n=document.querySelector("#dn").value.trim(),a=+document.querySelector("#da").value,note=document.querySelector("#dnote").value.trim();if(!n||a<=0)return alert("নাম ও টাকা দিন");addDueRecord(kind,n,a,note);save();render()}
function removeDue(kind,i){if(confirm("এন্ট্রি মুছবেন?")){db[kind].splice(i,1);save();render()}}
function addExpense(){const n=document.querySelector("#en").value.trim(),a=+document.querySelector("#ea").value;if(!n||a<=0)return alert("খরচের নাম ও টাকা দিন");db.expenses.push({date:today(),name:n,amount:a});save();render()}
function exportData(){const blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="raw-nation-backup-"+today()+".json";a.click();URL.revokeObjectURL(a.href)}
function importData(e){const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{db=JSON.parse(r.result);save();alert("Backup restore হয়েছে");render()}catch(_){alert("Backup file ঠিক নয়")}};r.readAsText(f)}
function showLogin(){
 document.querySelector("#login").innerHTML=`<div class="login-wrap"><div class="login-card">
 <img class="login-logo" src="logo.jpg" alt="RN">
 <h1>RAW NATION</h1><p>Salman • Secure Login</p>
 <input id="pinInput" class="pin" inputmode="numeric" maxlength="6" type="password" placeholder="PIN">
 <button class="login-btn" onclick="pinLogin()">🔐 PIN দিয়ে Login</button>
 <button class="login-btn bio-btn" onclick="biometricLogin()">◉ Face / Device Verify</button>
 <div id="loginMsg" class="login-msg"></div>
 </div></div>`;
}
function unlock(){
 document.querySelector("#login").style.display="none";
 document.querySelector("#mainHeader").style.display="";
 document.querySelector("#nav").style.display="";
 document.querySelector("#app").style.display="";
 nav();render();
}
function pinLogin(){
 const v=document.querySelector("#pinInput").value;
 if(v==="1204"){sessionStorage.setItem("rn_auth","1");unlock()}
 else document.querySelector("#loginMsg").textContent="PIN সঠিক নয়। আবার চেষ্টা করুন।";
}
async function biometricLogin(){ if(window.AndroidBio){ AndroidBio.authenticate(); return; }
 const msg=document.querySelector("#loginMsg");
 if(!window.PublicKeyCredential){msg.textContent="এই browser-এ Face/Device Verify support নেই। PIN 1204 ব্যবহার করুন।";return}
 try{
   const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
   if(!available){msg.textContent="এই ডিভাইসে supported biometric পাওয়া যায়নি। PIN 1204 ব্যবহার করুন।";return}
   // This is a device-biometric convenience check. Full WebAuthn cryptographic
   // verification requires an HTTPS backend; the offline app therefore keeps PIN
   // as the secure fallback and does not store face images.
   if(!localStorage.getItem("rn_bio_enabled")){
     msg.textContent="Face/Device Verify চালু করতে অ্যাপটিকে HTTPS/Android native version-এ সেটআপ করতে হবে। এখন PIN 1204 ব্যবহার করুন।";
     return;
   }
   const challenge=crypto.getRandomValues(new Uint8Array(32));
   await navigator.credentials.get({publicKey:{
     challenge,timeout:60000,userVerification:"required",
     allowCredentials:[{id:Uint8Array.from(atob(localStorage.getItem("rn_bio_id")),c=>c.charCodeAt(0)),type:"public-key",transports:["internal"]}]
   }});
   unlock();
 }catch(e){msg.textContent="Verify হয়নি। PIN 1204 দিয়ে Login করুন।";}
}
function logout(){sessionStorage.removeItem("rn_auth");location.reload();}
if(sessionStorage.getItem("rn_auth")==="1") unlock(); else showLogin();