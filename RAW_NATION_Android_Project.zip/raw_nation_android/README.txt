RAW NATION Android Project
App: RAW NATION | Owner: Salman | PIN: 1204
Open this folder in Android Studio, sync Gradle, then Build > Build APK(s).
The APK will install as a normal Android app. Face/Fingerprint uses Android system biometric when supported; PIN 1204 remains fallback.
